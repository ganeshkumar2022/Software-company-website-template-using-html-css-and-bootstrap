<footer class="bg-dark mt-5">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-4">
                <img src="images/logo.png" style="height:80px;">
                <p class="mytexta text-justify my-3 text-secondary">
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Accusantium eos eius numquam, pariatur consequuntur beatae voluptates ad dolorum assumenda ducimus!
                </p>
                <p class="text-justify text-secondary mytexta">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quas, soluta!
                    Lorem ipsum dolor sit amet.
                </p>
            </div>
            <div class="col-md-4">
                <h4 class="text-white">Portfolio</h4>
                <p class="mt-5 mymila"><a href="inex.php" class="text-secondary">Home</a></p>
                <p class="mymila"><a href="about.php" class="text-secondary mytexta">About us</a></p>
                <p class="mymila"><a href="services.php" class="text-secondary mytexta">Our Services</a></p>
                <p class="mymila"><a href="portfolio.php" class="text-secondary mytexta">Portfolio</a></p>
                <p class="mymila"><a href="contact.php" class="text-secondary mytexta">Contact</a></p>
            </div>
            <div class="col-md-4">
                <h4 class="text-white">Subscribe</h4>
                <p class="mt-5 text-secondary mytexta text-justify">
                    Lorem ipsum dolor ipsum this is assumenda ducimus! sit amet consectetur, adipisicing elit. Expedita quos vero, ea optio ullam natus ipsam itaque odio corrupti architecto!
                </p>

                <div class="input-group input-group-lg myinputg mb-3">
                    <input type="text" class="form-control text-dark" style="background-color:black;border-color:black;" placeholder="Subscribe our newsletter">
                    <div class="input-group-append">
                    <span class="input-group-text"  style="background-color:black;border-color:black;"><i class="fa-regular fa-envelope"></i></span>
                    </div>
                </div>
            </div>
            
    </div>
</div>
    <div style="background-color:black;" class="pt-4 pb-3">
               <p class="text-secondary text-center">All Rights Reserved. &copy; <?=date('Y')?> <span class="text-white">Example Web solutions</span> Design by
                <span class="text-white">Ganesh kumar</span></p>
               </div>
            </div>
</footer>
