
    <div class="bg-dark p-2">
       <a href="mailto:example@gmail.com" class="text-decoration-none text-white ml-2"><i class="fa-regular fa-envelope"></i> example@gmail.com</a> 
       <a href="tel:+919542345665" class="text-decoration-none text-white ml-2"><i class="fa-solid fa-phone"></i> +91 95423 45665</a>

       <span class="float-right mr-2">
       <a href="" class="text-decoration-none text-white ml-2"><i class="fa-brands fa-square-facebook head-social"></i></a> 
       <a href="" class="text-decoration-none text-white ml-2"><i class="fa-brands fa-instagram head-social"></i></a>
       <a href="" class="text-decoration-none text-white ml-2"><i class="fa-brands fa-youtube head-social"></i></a> 
       <a href="" class="text-decoration-none text-white ml-2"><i class="fa-brands fa-linkedin head-social"></i></a>
       <a href="" class="text-decoration-none text-white ml-2"><i class="fa-brands fa-square-twitter head-social"></i></a> 
        
       </span>
    </div>
    <nav class="navbar navbar-expand-md bg-white navbar-light mt-n1" style="width:100%;">
  <!-- Brand -->
  <a class="navbar-brand" href="#"><img src="images/logo.png" style="height:70px;"></a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse myheader" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link font-weight-bold" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold" href="about.php">About us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold" href="services.php">Our services</a>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold" href="portfolio.php">Portfolio</a>
      </li>
      <li class="nav-item">
        <a class="nav-link font-weight-bold" href="contact.php">Contact</a>
      </li>
    </ul>
  </div>
</nav>
